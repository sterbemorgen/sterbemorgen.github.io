---
title: "Tears"
date: 2023-04-30
description: 
categories: ["introspective"]
aliases: ["/introspective"]
tags: ["dementor"]
---


At what moment do we truly experience joy?

As of late, my emotional state has been increasingly unstable. Today,  I found myself on the brink of tears in public, yet I managed to maintain composure.However, once I returned home, I crumbled under the weight of my own thoughts. There was no apparent reason for it.Memories from the past persistently invade my mind, impervious to my attempts at dispelling them.

I recall reading that during bouts of depression, one ought to strive to recall moments of joy. But in my case, such instances are difficult to pinpoint. 

I have undoubtedly experienced happiness in my life, but it has never seemed to leave a lasting impression. Conversely, negative, sorrowful, awkward, and revolting thoughts and recollections linger on and on, unbidden.

One would expect happiness to accompany socializing with friends, but even such interactions leave me feeling depleted and weary. When alone, it is as though a malevolent force has drained the vitality from my very soul.

Do people realize when they are truly happy? I wonder if I ever do.