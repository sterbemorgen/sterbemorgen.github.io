
---
title: "sad girl summer"
summary: 
date: 2025-02-14
series: ["appreciation"]
aliases: ["/appreciation"]
tags: ["music"]
---
去年九月這首歌發行之後就一直在等這張專輯，真的先行曲太先行了吧，到現在也沒出。  
聽完好平靜喔，不知不覺聽了半年⋯⋯  

{{< applemusic "jp/song/sad-girl-summer/1764553891" >}}
