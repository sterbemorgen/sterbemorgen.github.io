
---
title: "SCOTT & BAILEY"
summary: 
date: 2023-04-28
series: ["appreciation"]
aliases: ["/appreciation"]
tags: ["movies"]
---

{{< neodbcard "https://neodb.social/tv/season/39zEiixdDyShamGjafEkx1" >}}

既然說到這部劇了，就推薦一下。非常好看。

主角是曼徹斯特警局的兩個女刑警探Janet Scott和Rachel Bailey。基本上是一集一個案子，緊湊精彩。Janet是資深警探，擅長調查兒童和家暴，非常冷靜，是Rachel的定海神針。Rachel年輕有衝勁，擅長跟蹤和突襲，會被情緒控制。配角也刻畫得非常打動我，我特別喜歡Gill。裡面所有女的都可愛得要死。最後一季還有一個Chinese lesbian哈哈哈哈哈。

劇情能讓所有女的產生共鳴，而且很注重細節，除了緊張刺激的辦案場景之外還有家庭生活，窒息的地方也絕對可以讓所有女的深深共情。大家都有大家的苦，就把女的會遇到的各種離譜的事情都非常自然地表現出來了。然後女的還能就著眼前的爛攤子繼續活得很精彩。

這部劇選的社會議題都是性別歧視，家庭暴力，強姦之類的非常貼合實際。一共5季，我好像每季都是五星推薦。入選我近年看過最好看的劇集榜單。