
---
title: "Saviors"
summary: 
date: 2024-01-20
categories: ["appreciation"]
aliases: ["/appreciation"]
tags: ["music"]
---

{{< applemusic "jp/album/saviors/1711049681" >}}
Saviors-Green Day

2024了，Green Day還是很好聽❤️