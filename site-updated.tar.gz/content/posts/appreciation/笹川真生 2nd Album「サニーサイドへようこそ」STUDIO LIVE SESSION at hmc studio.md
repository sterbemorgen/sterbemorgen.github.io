
---
title: "笹川真生 2nd Album「サニーサイドへようこそ」STUDIO LIVE SESSION at hmc studio"
summary: 
date: 2024-04-29
categories: ["appreciation"]
aliases: ["/appreciation"]
tags: ["music"]
---

{{< youtube Xaiu3TuP9Ws >}}


我特別特別特別喜歡的笹川真生。當時聽他的時候還是ボカロP，也是無意中聽到的瞬間愛上。

直到以「mao sasagawa」活動的時候，我才看到現場。那時候還是長髮，幾乎看不到臉，自我覺得真的和我好像的一個人喔（自作多情）。離開東京之前看的最後一場live已經是用「笹川真生」開始活動了。

這張專輯是繼「we are friends」之後最喜歡的一張，循環了好多好多個沒有陽光的冬日。和ww說即使是之前的供曲，他唱起來也感覺好不一樣，真的唱到我的靈魂裡去了，會一次次愛上他。

誠邀我的朋友們一起聽聽，雖然我之前已經各種平台發了無數遍了😊