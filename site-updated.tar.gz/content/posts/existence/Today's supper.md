---
title: "Today's supper"
date: 2023-10-17
lastmod: 2023-10-17
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/IMG_9599.jpg)
「クノール® スープDELI®」えびとほうれん草のクリームグラタン

![Alt text](/images/IMG_9600.jpg)
明星 辛麺屋輪監修 汁なし

Bought stuff on sale.