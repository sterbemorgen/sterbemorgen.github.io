---
title: "A bounteous banquet of fruits"
date: 2023-06-17
lastmod: 2023-06-17
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/IMG_9006.jpg)
🍇🫐🍒