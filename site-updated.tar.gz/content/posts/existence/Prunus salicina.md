---
title: "Prunus salicina"
date: 2023-08-15
lastmod: 2023-08-15
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/IMG_9297.jpg)
![Alt text](/images/IMG_9301.jpg)
Mightily delectable paired with “Heartstopper”❤️‍🔥