---
title: "ichijiki"
date: 2023-06-12
lastmod: 2023-06-12
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/PBK_0829.JPG)
パスタ

{{< youtube fjb5gEQtb1w >}}
きょうは、小橋さんがくれたパスタ作ったけど、本当にパスタの味がしたわ。でも、電子レンジの掃除も、鍋とお椀とお皿の洗い物もあるから、短期間でまた作らんと思うわ。私の食堂に戻るつもりやねん。