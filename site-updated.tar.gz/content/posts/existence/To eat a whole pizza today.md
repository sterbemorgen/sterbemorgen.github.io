---
title: "To eat a whole pizza today"
date: 2023-10-25
lastmod: 2023-10-25
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/lapizza.jpg)
ラ・ピッツァ　マルゲリータ

{{< youtube 31LFbPsgzL8 >}}
Still a very simple meal.