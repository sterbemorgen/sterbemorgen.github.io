---
title: "Recent supplements"
date: 2023-10-17
lastmod: 2023-10-17
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/IMG_9597.jpg)
Striving for a less agonizing experience before passing