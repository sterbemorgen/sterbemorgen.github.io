---
title: "Monday"
date: 2023-05-15
lastmod: 2023-05-15
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["teaser"]
---

![Alt text](/images/IMG_9007.jpg)
friends💕

{{< youtube tWgPvhaSb1Q >}}
perambulating through Kyoto wiz friends