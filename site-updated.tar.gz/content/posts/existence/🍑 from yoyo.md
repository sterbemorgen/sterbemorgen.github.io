---
title: "🍑 from yoyo"
date: 2023-07-28
lastmod: 2023-07-28
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["unboxing"]
---

![Alt text](/images/PBK_1406.JPG)
🍑

{{< youtube _5d-Q1z5jmM >}}
Dear yoyo, my friend, sent me a crate of peaches.