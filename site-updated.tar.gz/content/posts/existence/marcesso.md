---
title: "marcesso"
date: 2023-06-11
lastmod: 2023-06-11
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["hana"]
---

![Alt text](/images/IMG_8973.jpg)
一边盛放，一边凋零