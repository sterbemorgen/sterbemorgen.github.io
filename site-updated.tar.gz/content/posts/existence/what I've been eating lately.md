---
title: "what I've been eating lately"
date: 2023-10-24
lastmod: 2023-10-24
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/pizza.JPG)
石窯工房® あら挽きソーセージ

{{< youtube IZfwKurVUlc >}}
In just 40 seconds, you've got a quick meal that's both easy to make and devour. 
Perfect for those mornings when you can't get out of bed!
