---
title: "Morning Repast in the Summer"
date: 2023-06-13
lastmod: 2023-06-13
description: 
series: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/PBK_0830.JPG)
夏やったら、カルビーのフルグラ食べるんやで！