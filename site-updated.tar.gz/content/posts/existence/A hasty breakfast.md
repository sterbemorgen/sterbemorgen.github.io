---
title: "A hasty breakfast"
date: 2023-06-16
lastmod: 2023-06-16
description: 
categories: ["existence"]
aliases: ["/existence"]
tags: ["repast"]
---

![Alt text](/images/IMG_8994.jpg)
lemon cakes