---
title: "{{ replace .File.ContentBaseName "-" " " | title }}"
date: {{ .Date }}
draft: true
categories: ["Perusal"]  # 可选: Perusal, Appreciation, Introspective, Existence
tags: []
description: ""
author: "Khonzy"
# weight: 1  # 文章排序权重
# cover:
#   image: "/images/cover.jpg"
#   alt: "封面图片描述"
#   caption: "图片说明"
# showToc: true  # 是否显示目录
# TocOpen: false  # 默认展开目录
---

## 引言

在这里写一些引导性的内容...

## 正文

### 小标题一

内容...

### 小标题二

更多内容...

## 结论

总结性的内容...

---

**参考资料:**

1. [链接标题](https://example.com)
2. 书籍或文章标题
